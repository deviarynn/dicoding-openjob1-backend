module.exports = (schema) => (req, res, next) => {
  const { error } = schema.validate(req.body);

  if (error) {
    return res.status(400).json({
      status: 'failed',
      message: error.message,
    });
  }

  next();
};